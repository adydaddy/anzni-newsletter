module.exports = {
   server : "mongodb://127.0.0.1/iVoice/",
   secret: 'AnZNewsLetter'
}
